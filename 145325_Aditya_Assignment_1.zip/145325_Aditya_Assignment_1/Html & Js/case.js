function addProduct(){

 var data=document.form2.level.value;

  if(data=="ug"){
        document.form2.equal.innerHTML="<option value='select'>Select your qualification</option>"+
                               "<option value='bsc'>BSC</option>"+
							   "<option value='ba'>BA</option>"+
							   "<option value='bcom'>BCOM</option>";
							   }
							   
  if(data=="pg"){
        document.form2.equal.innerHTML="<option value='select'>Select your qualification</option>"+
                               "<option value='ma'>MA</option>"+
							   "<option value='mtech'>Mtech</option>"+
							   "<option value='mca'>MCA</option>"+
							   "<option value='mba'>MBA</option>";
							   }
							 
}			

function validateData()
{

var msg="true";

var name=document.form2.ename.value;
var phonenumber=document.form2.phone.value;
var dob=document.form2.dob.value;
today = new Date();
var dob_year=dob.substring(0,4);
myDate=new Date();
myDate.setFullYear(dob_year);
var age = today.getFullYear()-myDate.getFullYear();
var email=document.form2.pemail.value;
var level=document.form2.level.value;
var qualification=document.form2.equal.value;
if(qualification=='select')
{
alert("Qualification should be selected......");
msg="false";
}
if(msg=="true")
{
alert("Name:"+name+"  Age:"+age+"  Phone Number:"+phonenumber+"  Email:"+email+"  Qualification:"+qualification+"  Graduation Level:"+level);
}

}